from django.db import models
from django.contrib.auth.models import User


class JobApplication(models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        null=True,
        blank=True
    )

    company_name = models.CharField(max_length=200)
    job_title = models.CharField(max_length=200)
    location = models.CharField(max_length=100)
    application_source = models.CharField(max_length=100)
    salary = models.CharField(max_length=100, blank=True)
    required_skills = models.TextField()

    application_status = models.CharField(
        max_length=50,
        default="Applied"
    )

    application_date = models.DateField()

    def __str__(self):
        return f"{self.company_name} - {self.job_title}"