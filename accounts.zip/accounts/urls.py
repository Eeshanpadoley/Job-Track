from django.urls import path

from .views import (
    login_view,
    register_view,
    logout_view,
    dashboard_view,
    add_application_view,
    analytics_view,
    my_applications_view,
    edit_application_view,
    delete_application_view,
    pandas_analysis_view,
)

urlpatterns = [
    path("login/", login_view, name="login"),
    path("register/", register_view, name="register"),
    path("logout/", logout_view, name="logout"),
    path("dashboard/", dashboard_view, name="dashboard"),
    path("add-application/", add_application_view, name="add_application"),
    path("analytics/", pandas_analysis_view, name="analytics"),
    path("my-applications/", my_applications_view, name="my_applications"),
    path(
        "edit-application/<int:application_id>/",
        edit_application_view,
        name="edit_application",
    ),
    path(
        "delete-application/<int:application_id>/",
        delete_application_view,
        name="delete_application",
    ),
]