from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
import pandas as pd
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.utils import timezone

from .models import JobApplication


# =========================
# LOGIN
# =========================

def login_view(request):

    if request.method == "POST":

        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(
            username=username,
            password=password
        )

        if user is not None:
            login(request, user)
            return redirect("dashboard")

        messages.error(
            request,
            "Invalid username or password."
        )

    return render(
        request,
        "accounts/login.html"
    )


# =========================
# REGISTER
# =========================

def register_view(request):

    if request.method == "POST":

        username = request.POST.get("username")
        email = request.POST.get("email")
        password = request.POST.get("password")

        if User.objects.filter(username=username).exists():

            messages.error(
                request,
                "Username already exists."
            )

            return redirect("register")

        User.objects.create_user(
            username=username,
            email=email,
            password=password
        )

        messages.success(
            request,
            "Registration successful. Please login."
        )

        return redirect("login")

    return render(
        request,
        "accounts/register.html"
    )


# =========================
# DASHBOARD
# =========================

@login_required(login_url="login")
def dashboard_view(request):

    applications = JobApplication.objects.filter(
        user=request.user
    )

    total_applications = applications.count()

    interviews = applications.filter(
        application_status="Interview"
    ).count()

    offers = applications.filter(
        application_status="Offer"
    ).count()

    rejections = applications.filter(
        application_status="Rejected"
    ).count()

    context = {
        "total_applications": total_applications,
        "interviews": interviews,
        "offers": offers,
        "rejections": rejections,
    }

    return render(
        request,
        "accounts/dashboard.html",
        context
    )


# =========================
# ANALYTICS
# =========================

@login_required(login_url="login")
def analytics_view(request):

    applications = JobApplication.objects.filter(
        user=request.user
    )

    total_applications = applications.count()

    interviews = applications.filter(
        application_status="Interview"
    ).count()

    offers = applications.filter(
        application_status="Offer"
    ).count()

    rejections = applications.filter(
        application_status="Rejected"
    ).count()

    if total_applications > 0:

        interview_rate = round(
            (interviews / total_applications) * 100,
            2
        )

        offer_rate = round(
            (offers / total_applications) * 100,
            2
        )

        rejection_rate = round(
            (rejections / total_applications) * 100,
            2
        )

        success_rate = round(
            ((interviews + offers) / total_applications) * 100,
            2
        )

    else:

        interview_rate = 0
        offer_rate = 0
        rejection_rate = 0
        success_rate = 0

    context = {
        "total_applications": total_applications,
        "interviews": interviews,
        "offers": offers,
        "rejections": rejections,
        "interview_rate": interview_rate,
        "offer_rate": offer_rate,
        "rejection_rate": rejection_rate,
        "success_rate": success_rate,
    }

    return render(
        request,
        "accounts/analytics.html",
        context
    )


# =========================
# ADD APPLICATION
# =========================

@login_required(login_url="login")
def add_application_view(request):

    if request.method == "POST":

        company_name = request.POST.get(
            "company_name"
        )

        job_title = request.POST.get(
            "job_title"
        )

        location = request.POST.get(
            "location"
        )

        # Supports both possible form names
        application_source = request.POST.get(
            "application_source"
        )

        if not application_source:
            application_source = request.POST.get(
                "source"
            )

        salary = request.POST.get(
            "salary"
        )

        required_skills = request.POST.get(
            "required_skills"
        )

        # Supports both possible form names
        application_status = request.POST.get(
            "application_status"
        )

        if not application_status:
            application_status = request.POST.get(
                "status"
            )

        application_date = request.POST.get(
            "application_date"
        )

        if not application_date:
            application_date = timezone.now().date()

        JobApplication.objects.create(
            user=request.user,
            company_name=company_name,
            job_title=job_title,
            location=location,
            application_source=application_source,
            salary=salary,
            required_skills=required_skills,
            application_status=application_status,
            application_date=application_date
        )

        messages.success(
            request,
            "Job application added successfully!"
        )

        return redirect("dashboard")

    return render(
        request,
        "accounts/add_application.html"
    )


# =========================
# MY APPLICATIONS
# =========================

@login_required(login_url="login")
def my_applications_view(request):

    applications = JobApplication.objects.filter(
        user=request.user
    ).order_by("-application_date")

    search = request.GET.get(
        "search",
        ""
    ).strip()

    status = request.GET.get(
        "status",
        ""
    ).strip()

    source = request.GET.get(
        "source",
        ""
    ).strip()

    # SEARCH COMPANY OR JOB TITLE
    if search:

        applications = applications.filter(
            company_name__icontains=search
        ) | applications.filter(
            job_title__icontains=search
        )

    # STATUS FILTER
    if status:

        applications = applications.filter(
            application_status=status
        )

    # SOURCE FILTER
    if source:

        applications = applications.filter(
            application_source__icontains=source
        )

    context = {
        "applications": applications,
        "search": search,
        "status": status,
        "source": source,
    }

    return render(
        request,
        "accounts/my_applications.html",
        context
    )


# =========================
# EDIT APPLICATION
# =========================

@login_required(login_url="login")
def edit_application_view(
    request,
    application_id
):

    application = get_object_or_404(
        JobApplication,
        id=application_id,
        user=request.user
    )

    if request.method == "POST":

        application.company_name = request.POST.get(
            "company_name"
        )

        application.job_title = request.POST.get(
            "job_title"
        )

        application.location = request.POST.get(
            "location"
        )

        application.application_source = request.POST.get(
            "application_source"
        )

        if not application.application_source:
            application.application_source = request.POST.get(
                "source"
            )

        application.salary = request.POST.get(
            "salary"
        )

        application.required_skills = request.POST.get(
            "required_skills"
        )

        application.application_status = request.POST.get(
            "application_status"
        )

        if not application.application_status:
            application.application_status = request.POST.get(
                "status"
            )

        application.save()

        messages.success(
            request,
            "Application updated successfully!"
        )

        return redirect(
            "my_applications"
        )

    context = {
        "application": application
    }

    return render(
        request,
        "accounts/edit_application.html",
        context
    )


# =========================
# DELETE APPLICATION
# =========================

@login_required(login_url="login")
def delete_application_view(
    request,
    application_id
):

    application = get_object_or_404(
        JobApplication,
        id=application_id,
        user=request.user
    )

    application.delete()

    messages.success(
        request,
        "Application deleted successfully!"
    )

    return redirect(
        "my_applications"
    )


# =========================
# LOGOUT
# =========================

@login_required(login_url="login")
def logout_view(request):

    logout(request)

    return redirect("login")


@login_required
def pandas_analysis_view(request):
    applications = JobApplication.objects.filter(user=request.user)

    data = list(applications.values(
        "company_name",
        "job_title",
        "application_source",
        "application_status",
        "required_skills",
        "application_date"
    ))

    df = pd.DataFrame(data)

    total_applications = len(df)

    if df.empty:
        company_summary = []
        status_summary = []
        interviews = 0
        offers = 0
        rejections = 0
    else:
        company_summary = (
            df.groupby("company_name")
            .size()
            .reset_index(name="count")
            .to_dict("records")
        )

        status_summary = (
            df.groupby("application_status")
            .size()
            .reset_index(name="count")
            .to_dict("records")
        )

        interviews = int(
            (df["application_status"] == "Interview").sum()
        )
        offers = int(
            (df["application_status"] == "Offer").sum()
        )
        rejections = int(
            (df["application_status"] == "Rejected").sum()
        )

    if total_applications > 0:
        interview_rate = round(
            interviews / total_applications * 100, 2
        )
        offer_rate = round(
            offers / total_applications * 100, 2
        )
        rejection_rate = round(
            rejections / total_applications * 100, 2
        )
        success_rate = round(
            (interviews + offers) / total_applications * 100, 2
        )
    else:
        interview_rate = 0
        offer_rate = 0
        rejection_rate = 0
        success_rate = 0

    context = {
        "company_summary": company_summary,
        "status_summary": status_summary,
        "total_applications": total_applications,
        "interviews": interviews,
        "offers": offers,
        "rejections": rejections,
        "interview_rate": interview_rate,
        "offer_rate": offer_rate,
        "rejection_rate": rejection_rate,
        "success_rate": success_rate,
    }

    return render(request, "accounts/analytics.html", context)

 